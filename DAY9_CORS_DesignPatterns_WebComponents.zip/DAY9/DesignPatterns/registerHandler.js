function registerHandler(theObject, theEvent, theHandler) {
  if (window.addEventListener) {
    theObject.addEventListener(theEvent, theHandler);
  } else if (window.attachEvent) {
    theObject.attachEvent(theEvent, theHandler);
  } else {
    theObject["on" + theEvent] = theHandler;
  }
}
