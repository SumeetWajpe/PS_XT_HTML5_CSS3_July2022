class HelloWorld extends HTMLElement {
  constructor() {
    super();
    console.log("Hello World Web Component !");
  }
}

customElements.define("hello-world", HelloWorld);
