class Tooltip extends HTMLElement {
  tooltip = null;
  tooltipText = "Dummy Value";
  constructor() {
    super();

    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    if (this.hasAttribute("text")) {
      this.tooltipText = this.getAttribute("text");
    }

    let tooltipIcon = document.createElement("span");
    tooltipIcon.innerText = "(?)";
    tooltipIcon.addEventListener("mouseenter", this.showTooltip.bind(this));
    tooltipIcon.addEventListener("mouseout", this.hideTooltip.bind(this));
    this.style.position = "relative";
    this.style.cursor = "pointer";
    this.shadowRoot.appendChild(tooltipIcon);
  }

  showTooltip() {
    this.tooltip = document.createElement("span");
    this.tooltip.innerText = this.tooltipText;
    this.tooltip.style.backgroundColor = "black";
    this.tooltip.style.color = "white";
    this.tooltip.style.position = "absolute";
    this.tooltip.style.top = "-10px";
    this.tooltip.style.left = "10px";
    this.tooltip.style.fontSize = "8px";
    this.tooltip.style.width = "150px";
    this.tooltip.style.padding = "3px";
    this.tooltip.style.border = "1px solid grey";
    this.tooltip.style.borderRadius = "3px";

    this.shadowRoot.appendChild(this.tooltip);
  }

  hideTooltip() {
    this.shadowRoot.removeChild(this.tooltip);
  }
}

customElements.define("uc-tooltip", Tooltip);
