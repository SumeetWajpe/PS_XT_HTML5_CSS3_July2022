//var MathModule = { PI: 3.14 };

var MathModule = (function (MathModule) {
  MathModule.Add = function (x, y) {
    return x + y;
  };

  function Product(x, y) {
    return x * y;
  }

  return MathModule;
})(MathModule || {});
