import * as MathModule from "./math.js";
console.log(`The addition is: ${MathModule.default(30, 50)}`);
console.log(`The multiplication is: ${MathModule.Product(30, 50)}`);

// import Addition from "./math.js";

// console.log(`The addition is: ${Addition(30, 50)}`);
