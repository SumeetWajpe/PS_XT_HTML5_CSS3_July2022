if (navigator.serviceWorker) {
  window.addEventListener("load", function () {
    this.navigator.serviceWorker
      .register("serviceworker.js")
      .then(() => console.log("Service Worker : Registered successfully !"))
      .catch(() => console.log("Service Worker :: Error Registering !"));
  });
}
