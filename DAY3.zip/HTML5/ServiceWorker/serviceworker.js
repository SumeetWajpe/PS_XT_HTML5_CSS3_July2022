let cacheAssests = ["Index.html", "About.html"];
let cacheName = "v4";
self.addEventListener("install", function (e) {
  console.log("Service Worker : Installing !");
  e.waitUntil(
    caches
      .open(cacheName)
      .then(function (cache) {
        cache.addAll(cacheAssests);
      })
      .then(() => {
        self.skipWaiting();
      }),
  );
});

self.addEventListener("activate", function (e) {
  console.log("Service Worker : Activating !");
  e.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(c => {
          if (c !== cacheName) {
            console.log("Deleting old cache !");
            return caches.delete(c);
          }
        }),
      );
    }),
  );
});

self.addEventListener("fetch", function (e) {
  console.log("Service Worker : Fetching !");
  e.respondWith(
    fetch(e.request).catch(() => {
      return caches.match(e.request); // fetch resources from the cache in case of n/w failure
    }),
  );
});
