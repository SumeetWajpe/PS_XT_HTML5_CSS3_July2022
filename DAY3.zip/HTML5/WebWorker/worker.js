onmessage = function (e) {
  // no access to window object (this refers to WorkerglobalScope)
  // no access to document object
  // no access to localStorage/sessionStorage
  // access to indexedDB / XMLHttpRequest / fetch
  let largeArray = [];

  for (let i = 0; i < 15000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 15000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[3000][4000]);
};

// console.log();
